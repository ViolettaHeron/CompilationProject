/* test*/


int main() {
  int a,b;
  a = 45000;
  b = -123;
}
