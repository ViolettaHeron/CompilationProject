/* A compiler avec gcc et a linker avec les fichiers de test */
#include <stdio.h>

int printd(int i) {
	printf("%d\n",i);
	return 0;
}
