/* TEST TABLEAUX MULTIDIMENSIONNELS MINIC */

int tab[3][4][5];

int main() {
  tab[1][2][3] = tab[0][1][2];
}
