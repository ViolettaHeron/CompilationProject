/* TEST TABLEAUX MINIC */

int tab[300];

int main() {
  tab[3] = tab[200];
  tab[400] = tab[0];
}
