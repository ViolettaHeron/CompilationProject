/* TEST VARIABLES MINIC */

int a;
int main() {
  int a, b;
  a = 0;
  b = 1;
}
