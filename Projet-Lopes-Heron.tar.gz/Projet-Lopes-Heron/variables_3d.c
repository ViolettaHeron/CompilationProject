/* FICHIER GENERE PAR LE COMPILATEUR MONGCC */

#include<stdlib.h>
#include<stdbool.h>
#include<stdio.h>

	int a;
int main() {
a	int b;
	a=0;
	b=1;
	}

